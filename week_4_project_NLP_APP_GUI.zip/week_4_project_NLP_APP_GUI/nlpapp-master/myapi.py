import nlpcloud

class API:
    def __init__(self):
        # Initialize the NLP Cloud client with your API key and model
        self.client = nlpcloud.Client("finetuned-llama-3-70b", "45d5ac738d39d251621d7601d8ff8ddf8ebd5ab9", gpu=True)

    def sentiment_analysis(self, text):
        # Perform sentiment analysis using NLP Cloud
        response = self.client.sentiment(text)
        return response

    # Uncomment and implement these methods if needed
    # def ner(self, text):
    #     response = self.client.entities(text)
    #     return response

    # def emotion_prediction(self, text):
    #     response = self.client.emotion(text)
    #     return response