# nlpapp
An API based NLP application created using Tkinter and OOP

Link for API - https://komprehend.io/api-wrappers
